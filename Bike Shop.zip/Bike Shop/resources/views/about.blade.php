<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About</title>
  <link rel="stylesheet" href="css/my.css">  
  <style>
    * {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

.container {
  padding: 0 16px;
  
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;

}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
  </style>
  </head>

<body id='mainbody' >

  <!-- Top NavBar -->
  <div  class="topNavbar ">
    <ul class="topNavbarItems">
      

      
      <div> <li>NOTIFICATIONS</li></div>

      <div class="search"><li ><input id='search' type="search" placeholder="Search"  ></li></div>


     <div><li><a href='login'>LOGIN </a></div>
     
    </ul>
  </div>
  <!-- SiledBar -->

  <div class="sidbar">

    <div class='menu'>MENU
      
    </div>

    <div class="box">
      <nav>
        <ul>
          <li><a href="/">HOME</a></li>
          <li><a href="payment">PAYMENT</a></li>
          <li><a href="service">SERVICES</a></li>
          <li><a href="report">REPORT YOUR PROBLEM</a></li>
          <li><a href="about">ABOUT US</a></li>
        </ul>
      </nav>
    </div>
  </div>
  <!-- slidshow -->
 <div class="slidshow">
 





<div class="about-section">
  <h1>About Us </h1>
  <p>We offer you the better choice .</p>
  <p>You can find here any kind of Bikes .</p>
</div>

<h2 style="text-align:center">Our Team</h2>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="asset/images/hassan.jpg" alt="" >
      <div class="container">
        <h2>MOHAMMAD HASSAN ZAHERZI</h2>
        <p class="title">CEO & Founder</p>
        <p>The web developer with ten years experince.</p>
        <p>HASSAN@email.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="/w3images/team2.jpg" alt="" style="width:100%">
      <div class="container">
        <h2>RAHMANULLAH FAZLI</h2>
        <p class="title">Co-founder and Director</p>
        <p>A good person with smatness.</p>
        <p>RAHMANULLAH@yahoo.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <img src="/w3images/team3.jpg" alt="" style="width:100%">
      <div class="container">
        <h2>ALI</h2>
        <p class="title">Designer</p>
        <p>The best designer.</p>
        <p>ALI@gmail.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
</div>
 </div>

     </body>
     </html>