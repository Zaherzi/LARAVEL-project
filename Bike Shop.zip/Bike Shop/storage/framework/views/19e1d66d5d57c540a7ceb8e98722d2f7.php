<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>services</title>
  <link rel="stylesheet" href="css/my.css">  
  <style>
    * {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  width: 95vh;
  
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
  
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>
</head>
  

<body id='mainbody' >

  <!-- Top NavBar -->
  <div  class="topNavbar ">
    <ul class="topNavbarItems">
      

      
      <div> <li>NOTIFICATIONS</li></div>

      <div class="search"><li ><input id='search' type="search" placeholder="Search"  ></li></div>


     <div><li><a href='login'>LOGIN </a></div>
     
    </ul>
  </div>
  <!-- SiledBar -->

  <div class="sidbar">

    <div class='menu'>MENU
      
    </div>

    <div class="box">
      <nav>
        <ul>
          <li><a href="/">HOME</a></li>
          <li><a href="payment">PAYMENT</a></li>
          <li><a href="service">SERVICES</a></li>
          <li><a href="report">REPORT YOUR PROBLEM</a></li>
          <li><a href="about">ABOUT US</a></li>
        </ul>
      </nav>
    </div>
  </div>
  <!-- slidshow -->
 <div class="slidshow">
 


<h2 style="text-align:center">Services</h2>

<div class="card">
  <img src="public\images\personicone.jpg "alt="" style="width:100%">
  <h1>Enjoy our servces</h1>
  <p class="price">$19.99</p>
  <p>Repaire your bikes here</p>
  <p><button>Use this service</button></p>
</div>

 </div>

     </body>
     </html><?php /**PATH C:\xampp\htdocs\Bike Shop\resources\views/services.blade.php ENDPATH**/ ?>