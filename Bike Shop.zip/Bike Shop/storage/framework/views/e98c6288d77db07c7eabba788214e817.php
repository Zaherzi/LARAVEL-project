<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

  
  <form method="post" action="<?php echo e(URL::to('signin')); ?>">
         <div class="f_wrapper">
          <?php echo e($errors->first('db')); ?>

          <div class="admin_panel">Store login</div>
           <div> </div>
           <div class="f_col">Admin Username</div><div class="f_col"><input name="username" type="text" class="inbox"></div>
           <div class="f_col_w"><span class="number"><?php echo e($errors->first('username')); ?></span></div>
           
           <div class="f_col">Password</div><div class="f_col"><input name="password" type="password" class="inbox"></div>
           <div class="f_col_w"><span class="number"><?php echo e($errors->first('password')); ?></span></div>
           
           <div class="f_col"> </div><div class="f_col"><a><input type="submit" value="Sign In"></a></div>
           <div class="f_col_w" style="height:10px;"> </div>
         </div>   
  </form>


</body>
</html><?php /**PATH C:\xampp\htdocs\laravel_projects\mm\resources\views/phplogin.blade.php ENDPATH**/ ?>