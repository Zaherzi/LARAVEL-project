<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HOME</title>
  <link rel="stylesheet" href="css/my.css">  
  </head>

<body id='mainbody' >

  <!-- Top NavBar -->
  <div  class="topNavbar ">
    <ul class="topNavbarItems">
      

      
      <div> <li>NOTIFICATIONS</li></div>

      <div class="search"><li ><input id='search' type="search" placeholder="Search"  ></li></div>


     <div><li><a href='login'>LOGIN </a></div>
     
    </ul>
  </div>
  <!-- SiledBar -->

  <div class="sidbar">

    <div class='menu'>MENU
      
    </div>

    <div class="box">
      <nav>
        <ul>
          <li><a href="#">HOME</a></li>
          <li><a href="checkout">SHOP</a></li>
          <li><a href="service">SERVICES</a></li>
          <li><a href="report">REPORT YOUR PROBLEM</a></li>
          <li><a href="about">ABOUT US</a></li>
        </ul>
      </nav>
    </div>
  </div>
  <!-- slidshow -->
 <div class="slidshow">

 </div>

     </body>
     </html><?php /**PATH C:\xampp\htdocs\laravel_projects\mm\resources\views/pay.blade.php ENDPATH**/ ?>