<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HOME</title>
  <link rel="stylesheet" href="css/my.css">  
  <style>
    * {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: blue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  
  background-color:green;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 20%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
  </style>
  </head>

<body id='mainbody' >

  <!-- Top NavBar -->
  <div  class="topNavbar ">
    <ul class="topNavbarItems">
      

      
      <div> <li>NOTIFICATIONS</li></div>

      <div class="search"><li ><input id='search' type="search" placeholder="Search"  ></li></div>


     <div><li><a href='login'>LOGIN </a></div>
     
    </ul>
  </div>
  <!-- SiledBar -->

  <div class="sidbar">

    <div class='menu'>MENU
      
    </div>

    <div class="box">
      <nav>
        <ul>
          <li><a href="/">HOME</a></li>
          <li><a href="payment">PAYMENT</a></li>
          <li><a href="service">SERVICES</a></li>
          <li><a href="report">REPORT YOUR PROBLEM</a></li>
          <li><a href="about">ABOUT US</a></li>
        </ul>
      </nav>
    </div>
  </div>
  <!-- slidshow -->
 <div class="slidshow">

<h2>Login here</h2>

<form action="<?php echo e(url('/')); ?>/register" method="post">
  <?php echo csrf_field(); ?>
  <div class="imgcontainer">
    <img src="assets\images\personicone.jpg" alt="Avatar" class="avatar" >
  </div>

  <div class="container">
    <div>
     <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>
    <span class="text-danger">
      <?php $__errorArgs = ['uname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <?php echo e(massege()); ?>

      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
    </div>

    <div>
    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
    <span class="text-danger">
      <?php $__errorArgs = ['psw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <?php echo e(massege()); ?>

      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
    </div>

    
    <button type="submit">Login</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>
</form>
 </div>

     </body>
     </html><?php /**PATH C:\xampp\htdocs\laravel_projects\Bike Shop\resources\views/loginform.blade.php ENDPATH**/ ?>