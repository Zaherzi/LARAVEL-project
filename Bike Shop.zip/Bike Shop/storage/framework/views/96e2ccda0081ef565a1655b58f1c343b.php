<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HOME</title>
  <link rel="stylesheet" href="css/my.css">  
  <style>
    * {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: blue;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
  </style>
  </head>

<body id='mainbody' >

  <!-- Top NavBar -->
  <div  class="topNavbar ">
    <ul class="topNavbarItems">
      

      
      <div> <li>NOTIFICATIONS</li></div>

      <div class="search"><li ><input id='search' type="search" placeholder="Search"  ></li></div>


     <div><li><a href='login'>LOGIN </a></div>
     
    </ul>
  </div>
  <!-- SiledBar -->

  <div class="sidbar">

    <div class='menu'>MENU
      
    </div>

    <div class="box">
      <nav>
        <ul>
          <li><a href="/">HOME</a></li>
          <li><a href="payment">PAYMENT</a></li>
          <li><a href="service">SERVICES</a></li>
          <li><a href="report">REPORT YOUR PROBLEM</a></li>
          <li><a href="about">ABOUT US</a></li>
        </ul>
      </nav>
    </div>
  </div>
  <!-- slidshow -->
 <div class="slidshow">
 


<h3>Report your problem</h3>

<div class="container">
  <form action="/action_page.php">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="country">Country</label>
    <select id="country" name="country">
        <option value="usa">AFGHANISTAN</option>
      <option value="australia">Australia</option>
      <option value="canada">Canada</option>
      <option value="usa">USA</option>
    </select>

    <label for="subject">Report your problem here</label>
    <textarea id="subject" name="subject" placeholder="Write something about your issue.." style="height:200px"></textarea>

    <input type="submit" value="Submit">
  </form>
</div>
 </div>

     </body>
     </html><?php /**PATH C:\xampp\htdocs\laravel_projects\mm\resources\views/report.blade.php ENDPATH**/ ?>