<?php

use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/login', function () {
    return view('loginform');
});
Route::get('/service', function () {
    return view('services');
});
Route::get('/about', function () {
    return view('about');
});
Route::get('/report', function () {
    return view('report');
});
Route::get('/payment', function () {
    return view('payment');
});
Route::get('/pay', function () {
    return view('pay');
});
Route::get('/log', function () {
    return view('log');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


